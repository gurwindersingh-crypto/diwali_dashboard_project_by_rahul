const receiverName = document.querySelector("#receiver");
const senderName = document.querySelector("#sender");
receiverName.innerHTML = new URLSearchParams(location.search).get("receiver");
senderName.innerHTML = new URLSearchParams(location.search).get("sender");